/*
 * utils.c
 *
 *  Created on: Apr 21, 2018
 *      Author: drp1
 */


#include "utils.h"
